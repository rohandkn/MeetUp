package com.example.basehacks.meetup;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.client.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GoingFragment extends Fragment {
    private static final String ARG_TEXT = "arg_text";
    private static final String ARG_COLOR = "arg_color";
    private TextView text3;

    private String mText;
    private int mColor;

//    private View mContent;
//    private TextView mTextView;

    ListView simpleList;
    String countryList[] = {"hello", "whats up", "my mom"};
    ArrayList<String> list;
    Boolean run = false;
    View rootView;

    public static Fragment newInstance(String text, int color) {
        Fragment frag = new GoingFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLOR, color);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        list = new ArrayList<String>();
        rootView = inflater.inflate(R.layout.fragment_going, container, false);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();

        ref.child("users").child(FirebaseAuth.getInstance().getCurrentUser().getEmail().substring(0, FirebaseAuth.getInstance().getCurrentUser().getEmail().toString().indexOf("@"))).child("going").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Log.e("Count " ,""+snapshot.getChildrenCount());
                int i = 0;
                for (DataSnapshot postSnapshot: snapshot.getChildren()) {
                    String post = (String) postSnapshot.getValue();
                    Log.e("Get Data", post);
                    list.add(post);
                    removeDuplicates(list);
                    run = true;
                    run();
                    Log.v(FirebaseAuth.getInstance().getCurrentUser().getEmail().substring(0,FirebaseAuth.getInstance().getCurrentUser().getEmail().indexOf('@')), "ddfdfdfdf");

                    i++;
                }}

            @Override
            public void onCancelled(DatabaseError databaseError) {}

            public void onCancelled(FirebaseError firebaseError) {
                Log.e("The read failed: " ,firebaseError.getMessage());
            }

        });

        if(run) {
            simpleList = (ListView) rootView.findViewById(R.id.list_view);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this.getActivity(), R.layout.program_list, R.id.textView, list);
            simpleList.setAdapter(arrayAdapter);
        }

        return rootView;
    }

    public void run(){
        Log.v("length", String.valueOf(list.size()));
        simpleList = (ListView) rootView.findViewById(R.id.list_view);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this.getActivity(), R.layout.program_list, R.id.textView, list);
        simpleList.setAdapter(arrayAdapter);
        simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent myIntent = new Intent(GoingFragment.this.getActivity(), EventDetails.class);
                myIntent.putExtra("name", list.get(position));
                startActivity(myIntent);
            }
        });
    }

    public void removeDuplicates(ArrayList al){
// add elements to al, including duplicates
        Set<String> hs = new HashSet<>();
        hs.addAll(al);
        al.clear();
        al.addAll(hs);
    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        // retrieve text and color from bundle or savedInstanceState
//        if (savedInstanceState == null) {
//            Bundle args = getArguments();
//            mText = args.getString(ARG_TEXT);
//            mColor = args.getInt(ARG_COLOR);
//        } else {
//            mText = savedInstanceState.getString(ARG_TEXT);
//            mColor = savedInstanceState.getInt(ARG_COLOR);
//        }
//
//        // initialize views
//        mContent = view.findViewById(R.id.fragment_content);
//        mTextView = (TextView) view.findViewById(R.id.text_going);
//
//        // set text and background color
//        mTextView.setText(mText);
//        mContent.setBackgroundColor(mColor);
//
//
//    }
    public void createEvent(View v){
    Intent myIntent = new Intent(GoingFragment.this.getActivity(), CreateEvent.class);
    GoingFragment.this.startActivity(myIntent);
}

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putString(ARG_TEXT, mText);
        outState.putInt(ARG_COLOR, mColor);
        super.onSaveInstanceState(outState);
    }
}
