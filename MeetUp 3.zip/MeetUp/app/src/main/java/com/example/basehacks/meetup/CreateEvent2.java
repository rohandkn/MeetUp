package com.example.basehacks.meetup;
import android.Manifest;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.util.Calendar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class CreateEvent2 extends AppCompatActivity {

    private String meetingDetails;
    private List<String> emails;
    private String name;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference ref;
    private static final int PERMISSION_REQUEST_CODE = 1;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event2);
        emails = new ArrayList<String>();

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                name = null;
            } else {
                name = extras.getString("name");
            }
        } else {
            name = (String) savedInstanceState.getSerializable("name");
        }
    }

    public void onNext(View v) {
        EditText deets = (EditText)findViewById(R.id.details);
        meetingDetails = deets.getText().toString();
        EditText emailInput = (EditText)findViewById(R.id.friends);
        String allEmails = emailInput.getText().toString();
        emails = new ArrayList(Arrays.asList(allEmails.split("\\s*,\\s*")));
        for(int i =0; i<emails.size();i++){
            Intent in = new Intent(Intent.ACTION_SEND);
            in.setType("message/rfc822");
            in.putExtra(Intent.EXTRA_EMAIL  , new String[]{emails.get(i)});
            in.putExtra(Intent.EXTRA_SUBJECT, "subject of email");
            in.putExtra(Intent.EXTRA_TEXT   , "body of email");
            try {
                startActivity(Intent.createChooser(in, "Send mail..."));
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(CreateEvent2.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }
        }

        ref = FirebaseDatabase.getInstance().getReference();
        ref.child("events").child(name).child("details").setValue(deets.getText().toString());

        for (int i = 0; i < emails.size(); i++) {
            ref.child("events").child(name).child("invited").child(Integer.toString(i)).setValue(emails.get(i));
            ref.child("users").child(emails.get(i).substring(0,emails.get(i).indexOf('@'))).child("invited").child(String.valueOf(i)).setValue(name);
            ref.child("users").child(emails.get(i).substring(0,emails.get(i).indexOf('@'))).child("phone number").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    sendSMS(dataSnapshot.getValue().toString(), "I have invited you to join me at "+name+"! Open your MeetMe app to find out more!");
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }


    Intent myIntent = new Intent(CreateEvent2.this, MainActivity.class);
        CreateEvent2.this.startActivity(myIntent);
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.google.firebase.codelab.friendlychat");

    };

    private void sendSMS(String phoneNumber, String message) {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_DENIED) {

                Log.d("permission", "permission denied to SEND_SMS - requesting it");
                String[] permissions = {Manifest.permission.SEND_SMS};

                requestPermissions(permissions, PERMISSION_REQUEST_CODE);

            }
        }
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
        }

    public String returnDetails()
    {
        return meetingDetails;
    }

    public List<String> getEmails()
    {
        return emails;
    }
}