package com.example.basehacks.meetup;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.style.UpdateLayout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.basehacks.meetup.R;
import com.firebase.client.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class EventDetails extends AppCompatActivity {

    private String name;
    private String date;
    private String loc;
    private boolean going;
    private TextView time1;
    private DatabaseReference ref;
    private TextView location;
    private TextView info2;
    private ArrayList<String> arry;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);
        TextView eventName = (TextView) findViewById(R.id.inviteFriends);
        info2 = (TextView) findViewById(R.id.info);
        eventName.setText(name);
        arry = new ArrayList<String>();
        time1 = (TextView) findViewById(R.id.timet);
        location = (TextView) findViewById(R.id.loc);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                name = null;
            } else {
                name = extras.getString("name");
            }
        } else {
            name = (String) savedInstanceState.getSerializable("name");
        }

        ref = FirebaseDatabase.getInstance().getReference();

        ref.child("events").child(name).child("times").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if(arry.size()>3)
                    time1.setText(arry.get(3)+"/"+arry.get(0)+"/"+arry.get(4)+"at" + arry.get(1)+":"+arry.get(2));
                Log.e("Count " ,""+snapshot.getChildrenCount());
                Log.v("GetName", "jdjskj");
                for (DataSnapshot postSnapshot: snapshot.getChildren()) {
                    arry.add(postSnapshot.getValue().toString());
                 //   loc = postSnapshot.child("location").getValue().toString();

                    Log.v(arry.toString(),"ggggg");
                    if(arry.size()>4)
                        time1.setText("Date: "+arry.get(3)+"/"+arry.get(0)+"/"+arry.get(4)+" at " + arry.get(1)+":"+arry.get(2));
                    }}

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });






        ref.child("events").child(name).child("location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                location.setText("Location: " +dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        ref.child("events").child(name).child("details").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                info2.setText("Details: "+dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
if(arry.size()>3)
        time1.setText(arry.get(3)+"/"+arry.get(0)+"/"+arry.get(4)+"at" + arry.get(1)+":"+arry.get(2));




        // location.setText(loc);
    }

    public void onClickChat(View v){
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.google.firebase.codelab.friendlychat");
        launchIntent.putExtra("name", "name1");
        if (launchIntent != null) {
            startActivity(launchIntent);
    }}

    /**
     * When user selects "Going/NotGoing" clicked.
     * @param v
     */
    public void onRadioButtonClicked(View v)
    {
        boolean checked = ((RadioButton) v).isChecked();
        switch(v.getId()) {
            case R.id.going:
                if (checked) {
                    going = true;
                    ref.child("users").child(FirebaseAuth.getInstance().getCurrentUser().getEmail().substring(0, FirebaseAuth.getInstance().getCurrentUser().getEmail().toString().indexOf("@"))).child("going").child(name).setValue(name);
                    ref.child("events").child(name).child("going").child(FirebaseAuth.getInstance().getCurrentUser().getEmail().substring(0, FirebaseAuth.getInstance().getCurrentUser().getEmail().toString().indexOf("@"))).setValue(FirebaseAuth.getInstance().getCurrentUser().getEmail().substring(0, FirebaseAuth.getInstance().getCurrentUser().getEmail().toString().indexOf("@")));
                }

                break;
            case R.id.notGoing:
                break;
        }
    }
}