package com.example.basehacks.meetup;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;

@RequiresApi(api = Build.VERSION_CODES.N)
public class CreateEvent extends AppCompatActivity {
    EditText name;
    EditText loc;

    private String meetingName;
    private String meetingLocation;
    private DatePicker datePicker;
    private TimePicker timePicker;
    Button btnDatePicker, btnTimePicker;
    EditText txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;
    Calendar c = Calendar.getInstance();
    int startYear = c.get(Calendar.YEAR);
    int startMonth = c.get(Calendar.MONTH);
    int startDay = c.get(Calendar.DAY_OF_MONTH);
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference ref;
    private static final int PLACE_PICKER_REQUEST = 1;
    private TextView mName;
    private TextView mAddress;
    private TextView mAttributions;
    private String address1;
    private String name1;
    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(
            new LatLng(37.398160, -122.180831), new LatLng(37.430610, -121.972090));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        btnDatePicker=(Button)findViewById(R.id.btn_date);
        btnTimePicker=(Button)findViewById(R.id.btn_time);
        txtDate=(EditText)findViewById(R.id.in_date);
        txtTime=(EditText)findViewById(R.id.in_time);

        name = (EditText)findViewById(R.id.name);
        loc = (EditText)findViewById(R.id.location);
        Log.v("hour", " timePicker.getCurrentHour()");
    }

    public void onNext(View v) throws GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
        if (v == btnDatePicker) {

            meetingLocation = loc.getText().toString();
            meetingName = name.getText().toString();


            // Get Current Date
            final java.util.Calendar c = java.util.Calendar.getInstance();
            mYear = c.get(java.util.Calendar.YEAR);
            mMonth = c.get(java.util.Calendar.MONTH);
            mDay = c.get(java.util.Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {

            // Get Current Time
            final java.util.Calendar c = java.util.Calendar.getInstance();
            mHour = c.get(java.util.Calendar.HOUR_OF_DAY);
            mMinute = c.get(java.util.Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            txtTime.setText(hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }
    protected void onActivityResult(int requestCode,
                                    int resultCode, Intent data) {

        if (requestCode == PLACE_PICKER_REQUEST
                && resultCode == Activity.RESULT_OK) {

            Place place = PlacePicker.getPlace(data, this);
            final CharSequence name = place.getName();
            final CharSequence address = place.getAddress();
            String attributions = (String) place.getAttributions();
            if (attributions == null) {
                attributions = "";
            }
            name1 = name.toString();
            address1 = address.toString();
            loc.setText(name1+": " +address1,EditText.BufferType.EDITABLE);


            //  mName.setText(name);
            //mAddress.setText(address);
            //mAttributions.setText(Html.fromHtml(attributions));
          //  Log.v(mName.getText().toString(), mAddress.getText().toString());

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    public void run() throws GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
        PlacePicker.IntentBuilder intentBuilder =
                new PlacePicker.IntentBuilder();
        intentBuilder.setLatLngBounds(BOUNDS_MOUNTAIN_VIEW);
        startActivityForResult(intentBuilder.build(this), PLACE_PICKER_REQUEST);
    }
    public void locationon(View v) throws GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
        run();
    }

    public void onContinue(View v) throws GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
        ref = FirebaseDatabase.getInstance().getReference();
        ref.child("events").child(name.getText().toString());
        ref.child("events").child(name.getText().toString()).child("name").setValue(name.getText().toString());

        ref.child("events").child(name.getText().toString()).child("location").setValue(loc.getText().toString());
        ref.child("events").child(name.getText().toString()).child("times").child("year").setValue(mYear);
        ref.child("events").child(name.getText().toString()).child("times").child("month").setValue(mMonth);
        ref.child("events").child(name.getText().toString()).child("times").child("day").setValue(mDay);

        ref.child("events").child(name.getText().toString()).child("times").child("hour").setValue(mHour);
        ref.child("events").child(name.getText().toString()).child("times").child("minute").setValue(mMinute);
        Intent myIntent = new Intent(CreateEvent.this, CreateEvent2.class);
        myIntent.putExtra("name",name.getText().toString());
        CreateEvent.this.startActivity(myIntent);
    }
}